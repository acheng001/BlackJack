import java.util.Scanner;
import java.util.Random;

public class Main {

    //Global variables
    public static Scanner input;
    public static Random rand;

    public static void main(String[] args) {
	// write your code here
        mainInit();
        Game blackJack = new Game();
        Card c = new Card(Card.Suit.Hearts, 9);
        System.out.println(c.suit); //Prints Hearts because we set it to hearts
        System.out.println(c.number);
        blackJack.printDeck();

    } // Main

    //Main functions/methods
    private static void mainInit(){
        input = new Scanner(System.in); //Able to take an input from the user same as sc.scanner
        rand = new Random();
    } // mainInit

} //End of class Main
