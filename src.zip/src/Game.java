import java.util.Stack;
import java.util.Random;

public class Game {

    // Game Instance variables
    public static Stack<Card> deck = new Stack<>();

    public Game() {
        Main.input.next();
    }

    //Game Methods
    private void createDeck(){
        for(int i = 1; i <= 13; i++){
            deck.push(new Card(Card.Suit.Hearts,i));
            deck.push(new Card(Card.Suit.Diamonds,i));
            deck.push(new Card(Card.Suit.Spades,i));
            deck.push(new Card(Card.Suit.Clubs,i));
        }
    } //create Deck

    public void printDeck(){
        //This function prints all the cards in the deck
        //Note that the stack WE implemented, does not have a get() function, Java's does/

        for(int i = 1; i <= 13; i++){
            System.out.println(new Card(Card.Suit.Diamonds,i));
            System.out.println(new Card(Card.Suit.Diamonds,i));
            System.out.println(new Card(Card.Suit.Spades,i));
            System.out.println(new Card(Card.Suit.Clubs,i));
        }

    }
    public String toString(){
    }

    private void shuffleDeck(){
        //for each card in the deck, swap it with a random card in the deck.
        // look up get/set methods for stack
        //Search java stack docs.oracle
        // For swapping:
        // - Get a random card fromthe deck
        // - Store it in a temporary (temp) card variable.
        // - Set the current card (index i) to the temp
        // - Set the random (index r) to the Current card

        Random cards = new Random();

        for(int i = 1; i <= 13; i++){
            new Card(Card.Suit.Hearts,i);
        }



    } // shuffleDeck


} // public class Game
